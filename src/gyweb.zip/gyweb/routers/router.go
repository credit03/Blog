package routers

import (
	"../controllers/common"
	"../controllers"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/context"
)

func init() {
	//开启session
	beego.BConfig.WebConfig.Session.SessionOn = true
	//开启过滤（授权登录）
	Filter()
	beego.Router("/", &controllers.HomeController{})
	beego.Router(common.Category_search, &controllers.HomeController{}, "*:HandleCategory")

	beego.Router(common.Login_page_url, &controllers.UserController{}, "*:Get")
	beego.Router(common.To_login, &controllers.UserController{}, "*:Post")
	beego.Router("/myajax", &controllers.AjaxAuthController{}, "*:Post")

}

func Filter() {

	var FilterUser = func(ctx *context.Context) {
		_, ok := ctx.Input.Session("uid").(int)
		if !ok && ctx.Request.RequestURI != "/login" {
			ctx.Redirect(302, common.Login_page_url)
		}
	}

	//授权登录
	beego.InsertFilter("/myajax/*", beego.BeforeRouter, FilterUser)

}
