package main

import (
	"../models"
	"github.com/astaxie/beego/orm"
	"time"
	"fmt"
)

func init() {
	models.RegisterDB()
}
func main() {
	orm.Debug = true
	// 自动建表
	orm.RunSyncdb("default", true, true)

	o := orm.NewOrm()
	o.Using("default") // 默认使用 default，你可以指定为其他数据库

	u := &models.User{Name:"cre", Pic:"www.baidu.com",Pwd:"123456"}

	p1 := &models.Post{Title:"test1", Content:"如果需要通过条件", Author:u, Created:time.Now(), Updated:time.Now(), ReplyTime:time.Now()}
	p2 := &models.Post{Title:"test2", Content:"1234567890", Author:u, Created:time.Now(), Updated:time.Now(), ReplyTime:time.Now()}

	c1 := &models.Comment{Content:"d1", Uid:1, Time:time.Now(), Belong:p1}
	time.Sleep(1 * time.Second)
	c2 := &models.Comment{Content:"d2", Uid:1, Time:time.Now(), Belong:p1}
	time.Sleep(1 * time.Second)
	c3 := &models.Comment{Content:"d3", Uid:1, Time:time.Now(), Belong:p2}
	time.Sleep(1 * time.Second)
	c4 := &models.Comment{Content:"d4", Uid:1, Time:time.Now(), Belong:p2}

	fmt.Println(o.Insert(u))

	fmt.Println(o.Insert(p1))
	fmt.Println(o.Insert(p2))

	fmt.Println(o.Insert(c1))
	fmt.Println(o.Insert(c2))
	fmt.Println(o.Insert(c3))
	fmt.Println(o.Insert(c4))

	fmt.Println("直接查询。。。。")
	var posts []*models.Post
	num, err := o.QueryTable("post").Filter("Author", 1).RelatedSel().All(&posts)
	if err == nil {
		fmt.Printf("%d posts read\n", num)
		for _, post := range posts {
			fmt.Printf("Id: %d, UserName: %s, Title: %s\n", post.Id, post.Author.Name, post.Title)
		}
	}

	var cos []*models.Comment
	num, err = o.QueryTable("comment").Filter("Belong", 1).RelatedSel().All(&cos)

	if err == nil {
		fmt.Printf("%d comment read\n", num)
		for _, con := range cos {
			fmt.Printf("Id: %d, UserName: %s, CONTENT: %s; 帖子内容：%s\n", con.Id, con.Belong.Author.Name, con.Content, con.Belong.Content)
		}
	}

	//根据 User表的Posts.Author.Id 查询对应的 User：

	var u1 []*models.User
	num, err = o.QueryTable("user").Filter("Posts__Author__Id", "1").Limit(10).All(&u1)
	if err==nil{

		fmt.Printf("%d 查询对应的 User\n", num)
		for _, con := range u1 {
			fmt.Printf("Id: %d; UserName: %s; pic:%s\n", con.Id, con.Name, con.Pic)
		}
	}

}
