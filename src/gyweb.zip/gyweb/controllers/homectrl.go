package controllers

import (
	"./common"
	"../models"
	"github.com/astaxie/beego"
	"fmt"
	"github.com/astaxie/beego/orm"
)

type HomeController struct {
	beego.Controller
}
// 统一入口
func (this *HomeController) Get() {
	op := this.Input().Get("op")
	beego.Info("操作方式", op)
	switch op {
	case "category":
		tocategory(this)
	case "about":

	default:
		tohome(this)
	}

	return

}
//处理分类的操作
func (this *HomeController)HandleCategory() {

	optype := this.Input().Get("type")
	switch optype {
	case "add":
		search := this.Input().Get("search")
		err := models.CategoryAdd(search)
		if err == nil {
			tocategory(this)
			return
		}
	case "delete":
		id := this.Input().Get("uid")
		if models.CategoryDelete(id) == nil {
			tocategory(this)
			return
		}
	case "edit":
	default:
	}
	this.Redirect("/?op=category", 302)
	return

}
//分类
func tocategory(this *HomeController) {
	arr := common.GetNavData(1)
	this.Data["Arr"] = arr
	var p []models.Post
	o := orm.NewOrm()
	_, err := o.QueryTable("post").Limit(10).RelatedSel().All(&p)
	if err == nil {
		this.Data["listData"] = p
		this.Data["haveData"] = true
	}
	this.TplName = "category.html"
}
//首页
func tohome(this *HomeController) {

	arr := common.GetNavData(0)
	picarr := common.GetRollingPictureData(0)
	handarr := common.GetHandInfo()
	this.Data["Arr"] = arr
	this.Data["PicArr"] = picarr
	this.Data["HandArr"] = handarr
	this.TplName = "home.html"
}

//检查用户是否已登录
func CheckUser(this *HomeController) {
	/**
	   判断cookie与session
	 */
	uname, _, err := CheckUserCookie(this.Ctx)
	if err {
		v := this.GetSession(uname)
		if v == nil {
			this.Data["Islogin"] = true
		}
		s := "?type=logout&uname="
		this.Data["Admin"] = fmt.Sprint(common.Login_page_url, s, uname)
	} else {
		this.Data["Admin"] = fmt.Sprint(common.Login_page_url, "?type=login")
	}
}

func (this *HomeController) Prepare() {
	CheckUser(this)
}

