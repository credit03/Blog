package controllers

import "github.com/astaxie/beego"

type AjaxAuthController struct {
	beego.Controller
}
