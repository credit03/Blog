package controllers

import (
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/context"
	"fmt"
)

type UserController struct {
	beego.Controller
}

func (this *UserController) Get() {
	logtype := this.Input().Get("type")

	 if logtype == "logout" {
		uname := this.Input().Get("uname")
		if uname != "" {
			this.Ctx.SetCookie("uname", uname, -1, "/")
			this.Ctx.SetCookie("pwd", uname, -1, "/")
			this.DelSession(uname)
			this.Redirect("/", 302)
			return
		}

	}
	this.TplName = "login.html"
}

type User struct {
	Uname     string `form:"uname"`
	Pwd       string `form:"pwd"`
	Autologin string  `form:"autologin"`
}

func (this *UserController) Post() {

	u := User{}
	err := this.ParseForm(&u)
	fmt.Println("POST....输出", u, beego.AppConfig.String("uname"), beego.AppConfig.String("pwd"))

	if err == nil {
		if v := (u.Uname == beego.AppConfig.String("uname"))&&(u.Pwd == beego.AppConfig.String("pwd")); v {
			maxTime := 0
			if u.Autologin == "on" {
				maxTime = 1 << 32 - 1
			}
			this.Ctx.SetCookie("uname", u.Uname, maxTime, "/")
			this.Ctx.SetCookie("pwd", u.Pwd, maxTime, "/")
			this.SetSession("uname", u.Uname)
			this.Redirect("/", 302)
			return
		}
	}
	this.Data["err"] = true
	this.TplName = "login.html"

}

func CheckUserCookie(cxt *context.Context) (string, string, bool) {

	ck, err := cxt.Request.Cookie("uname")
	if err != nil {
		return "", "", false
	}

	pwd, err1 := cxt.Request.Cookie("pwd")
	if err1 != nil {
		return "", "", false
	}

	return ck.Value, pwd.Value, true
}




