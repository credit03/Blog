package common
/**
 导航栏ITEM
 */
type Nav struct {
	Active bool
	Url    string
	Name   string
}
/**
滚动图片
 */
type RollingPicture struct {
	Active   bool
	ImageUrl string
	Title    string
	Content  string
}

type HandInfo struct {
	ImageUrl string
	Title    string
	Content  string
	Url      string
}

func init() {
	initNav()
	initRollingPicture()
	initHandInfo()
}

var (
	handinfodata[] HandInfo
	navdata []Nav
	rollingPicturedata []RollingPicture
)

const (
	Login_page_url = "/user/loginpage"
	To_login = "/user/login"
	Category_search = "/category"
)

func initNav() {
	home := Nav{Url:"#", Name:"首页"}
	category := Nav{Url:"/?op=category", Name:"分类"}
	contact := Nav{Url:"/?op=contact", Name:"文章"}
	dynamic := Nav{Url:"/?op=dynamic", Name:"动态"}
	about := Nav{Url:"/?op=about", Name:"关于我们"}
	navdata = []Nav{home, category, contact, dynamic, about}
}
func initRollingPicture() {
	p1 := RollingPicture{ImageUrl:"/static/img/back-1.jpg", Title:"I love you", Content:"Dan"}
	p2 := RollingPicture{ImageUrl:"/static/img/back-2.jpg", Title:"中国梦", Content:"GY "}
	p3 := RollingPicture{ImageUrl:"/static/img/back-3.jpg", Title:"Pig and Dan.", Content:"My Life"}
	rollingPicturedata = []RollingPicture{p1, p2, p3}
}

func initHandInfo() {
	h1 := HandInfo{ImageUrl:"/static/img/24zw/photo1.jpg", Title:"Dan", Content:"StructTag 的定义用的标签用为form，和 ParseForm 方法 共用一个标签，标签后面有三个可选参数，用,分割。第一个参数为表单中类型的name的值，如果为空，则以struct field name为值。第二个参数为表单组件的类型，如果为空，则为text。表单组件的标签默认为struct field name的值，否则为第三个值。", Url:"#"}
	h2 := HandInfo{ImageUrl:"/static/img/24zw/photo2.jpg", Title:"Gy", Content:"如果form标签只有一个值，则为表单中类型name的值，除了最后一个值可以忽略外，其他位置的必须要有,号分割，如：form:,,姓名：", Url:"#"}
	h3 := HandInfo{ImageUrl:"/static/img/24zw/photo3.jpg", Title:"Dan and Gy", Content:"如果form标签只有一个值，则为表单中类型name的值，除了最后一个值可以忽略外，其他位置的必须要有,号分割，如：form:,,姓名：", Url:"#"}
	handinfodata = []HandInfo{h1, h2, h3}
}

func GetNavData(op int) []Nav {
	if op != 0 {
		navdata[0].Url = "/"
	}
	/**
	   清空选择
	 */
	for k, _ := range navdata {
		navdata[k].Active = false
	}
	navdata[op].Active = true
	return navdata
}

func GetRollingPictureData(op int) []RollingPicture {
	/**
	   清空选择
	 */
	for k, _ := range rollingPicturedata {
		rollingPicturedata[k].Active = false
	}
	rollingPicturedata[op].Active = true
	return rollingPicturedata
}

func GetHandInfo() []HandInfo {
	return handinfodata
}

