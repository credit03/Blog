package models

import (
	"time"
	"github.com/astaxie/beego/orm"
	_"github.com/go-sql-driver/mysql"
	_"github.com/mattn/go-sqlite3"
	"github.com/Unknwon/com"
	"os"
	"path"
	"errors"
	"github.com/astaxie/beego"
	"strconv"
)

const (
	_DB_NAME = "data/beeblog.db"
	_MYSQL_DRIVER = "mysql"
	_SQLITE3_DRIVER = "sqlite3"
)

type User struct {
	Id    int64                          //int, int32 - 设置 auto 或者名称为 Id 时 integer AUTO_INCREMENT
	Name  string `orm:"unique;size(24)"` //设置不为空并不能大小24个字符
	Pwd   string `orm:"unique;size(24)"` //设置不为空并不能大小24个字符
	Pic   string
	Posts []*Post `orm:"reverse(many)"`  // 设置一对多的反向关系
}

type Post struct {
	Id              int64
	Title           string `orm:"unique"`
	Content         string `orm:"size(5000)"`
	Author          *User  `orm:"rel(fk)"`            //设置一对多关系(外键)
	Created         time.Time `orm:"index"`           //为单个字段增加索引，例如用户选择某天xx时的文章，就可以根据这个索引匹配
	Updated         time.Time `orm:"index"`
	ReplyTime       time.Time `orm:"index"`
	ReplyCount      int64
	ReplyLastUserId int64
	Comments        []*Comment  `orm:"reverse(many)"` // 设置一对多的反向关系
}

type Comment struct {
	Id      int64
	Uid     int64
	Time    time.Time
	Content string`orm:"size(200)"`
	Belong  *Post `orm:"rel(fk)"`
}

func CategoryAdd(search string) (error) {
	o := orm.NewOrm()
	if CheckTitle(search) {
		user := User{Id: 1}
		err := o.Read(&user)
		if err == orm.ErrNoRows {
			beego.Warning("查询不到")
		} else if err == orm.ErrMissPK {
			beego.Warning("找不到主键")
		} else {
			beego.Info(user.Id, user.Name)
		}

		time.Now().Format(time.ANSIC)
		p := &Post{Title:search, Content:"12345", Author:&user, Created:time.Now(), Updated:time.Now(), ReplyTime:time.Now()}
		_, err = o.Insert(p)
		if err != nil {
			return errors.New("插入失败")
		}
		return nil
	}

	return errors.New("已经存在")
}
func CategoryDelete(id string) error {
	cid, err := strconv.ParseInt(id, 10, strconv.IntSize)
	if err == nil {
		o := orm.NewOrm()
		p := &Post{Id:cid}

		_, err = o.Delete(p)
	}
	return err
}

func CheckTitle(search string) bool {
	o := orm.NewOrm()
	qs := o.QueryTable("post")
	con, err := qs.Filter("Title", search).Count()
	if err != nil || con > 0 {
		return false
	}
	return true
}

func RegisterDB() {
	/**
	Using

	切换为其他数据库

	orm.RegisterDataBase("db1", "mysql", "root:root@/orm_db2?charset=utf8")
	orm.RegisterDataBase("db2", "sqlite3", "data.db")

	o1 := orm.NewOrm()
	o1.Using("db1")

	o2 := orm.NewOrm()
	o2.Using("db2")

	// 切换为其他数据库以后
	// 这个 Ormer 对象的其下的 api 调用都将使用这个数据库


	默认使用 default 数据库，无需调用 Using
	 */

	//使用多个数据库

	orm.RegisterModel(new(Comment), new(Post), new(User))
	orm.RegisterDriver(_MYSQL_DRIVER, orm.DRMySQL)
	//设置默认数据库
	orm.RegisterDataBase("default", _MYSQL_DRIVER, "root:java@/my_db?charset=utf8", 50)


	//判断是否创建了sqlite3数据库
	if !com.IsExist(_DB_NAME) {
		os.MkdirAll(path.Dir(_DB_NAME), os.ModePerm)
		os.Create(_DB_NAME)
	}
	orm.RegisterDriver(_SQLITE3_DRIVER, orm.DRSqlite)
	orm.RegisterDataBase("db2", _SQLITE3_DRIVER, _DB_NAME, 20)
}